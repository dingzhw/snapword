@echo off
chcp 65001 >nul
title 词哒 · SnapWord 伴学工作台
start "" "%~dp0SnapWord-词哒.html"
