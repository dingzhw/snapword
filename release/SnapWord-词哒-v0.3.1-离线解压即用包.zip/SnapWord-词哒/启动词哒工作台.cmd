@echo off
setlocal
cd /d "%~dp0"
for %%F in (*.html) do (
    start "" "%%~fF"
    exit /b 0
)
echo SnapWord HTML file not found in %~dp0
pause
